#!/usr/bin/env python
# coding: utf-8

# In[4]:


import requests
from bs4 import BeautifulSoup
import pandas as pd


#提取单页信息
def analysis(soup):
    temp = soup.find('div', class_="tslb_b") 
    df = pd.DataFrame(columns = ['id', 'brand', 'car_model', 'type', 'desc', 'problem', 'datetime', 'status']) 
    #找到所有的列数据   
    tr_list = temp.find_all('tr')
    for tr in tr_list:
        temp = {}
        #找到所有的行数据
        td_list = tr.find_all('td')
        if len(td_list)> 0: 
            #读取所有的数据
            id, brand, car_model, type, desc, problem, datatime, status = td_list[0].text, td_list[1].text, td_list[2].text, td_list[3].text, td_list[4].text, td_list[5].text, td_list[6].text, td_list[7].text
        
            #将读取的数据放入temp里
            temp['id'], temp['brand'], temp['car_model'], temp['type'], temp['desc'], temp['problem'], temp['datetime'], temp['status'] = id, brand, car_model, type, desc, problem, datatime, status 
        
            #m将读取的每一行数据插入DataFrame列表
            df = df.append(temp, ignore_index = True)
    return df
        
#抓取多页
page_num = 0 
base_url = 'http://www.12365auto.com/zlts/0-0-0-0-0-0_0-0-0-0-0-0-0-1' 
result = pd.DataFrame(columns = ['id', 'brand', 'car_model', 'type', 'desc', 'problem', 'datetime', 'status']) 
while page_num < 11:
    #请求新的页面
    request_url = base_url + str(page_num + 1)+ '.shtml'  
    
    #得到页面内容
    headers = {'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36'}
    html = requests.get(request_url, headers = headers, timeout=10)
    content = html.text
    
    #通过content创建BeautifulSoup对象
    soup = BeautifulSoup(content, 'html.parser')
    
    #调用函数
    df = analysis(soup)  
    
    #将新的一页数据插入列表
    result = result.append(df)
    
    #页码变化
    page_num = page_num + 1
    
result.to_csv('car_complain.csv', index=False) 



        


# In[ ]:





# In[ ]:




